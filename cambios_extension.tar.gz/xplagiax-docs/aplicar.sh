#!/usr/bin/env bash
# Aplica los cambios sobre UryxSoft/xplagiax_webextension.
# Uso:  bash aplicar.sh /ruta/al/repo
set -euo pipefail
REPO="${1:-.}"
AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RAMA="claude/ai-content-detection-platform-k3pa7d"
BASE="9588f53"

cd "$REPO"
git rev-parse --git-dir >/dev/null 2>&1 || { echo "ERROR: $REPO no es un repositorio git"; exit 1; }
git cat-file -e "$BASE^{commit}" 2>/dev/null || { echo "ERROR: falta el commit $BASE. Ejecuta: git fetch origin main"; exit 1; }
[ -z "$(git status --porcelain)" ] || { echo "ERROR: hay cambios sin confirmar. Haz commit o stash primero."; exit 1; }

echo "==> Rama $RAMA desde $BASE"
git checkout -B "$RAMA" "$BASE"
echo "==> Aplicando 2 commits"
git am --3way < "$AQUI/cambios.patch"

echo; echo "Resultado:"; git log --oneline -3
echo; echo "Estructura:"
for p in docs/00-resumen-ejecutivo.md docs/adr/ADR-010-extinction-gpl.md \
         packages/kernel/src/index.ts packages/detectors/extinction-validator/src/index.ts \
         apps/extension/wxt.config.ts chrome_extension/README.md; do
  [ -e "$p" ] && echo "  ok    $p" || echo "  FALTA $p"
done
for p in pkg cambios_extension.tar.gz; do
  [ -e "$p" ] && echo "  SOBRA $p" || echo "  ok    $p eliminado"
done

echo; echo "==> Verificando (requiere pnpm)"
if command -v pnpm >/dev/null 2>&1; then
  pnpm install --silent && pnpm exec vitest run 2>&1 | grep -E 'Test Files|Tests ' || true
else
  echo "  pnpm no instalado; omitido. Instálalo con: corepack enable"
fi

echo; echo "Si todo esta correcto:  git push -u origin $RAMA"
